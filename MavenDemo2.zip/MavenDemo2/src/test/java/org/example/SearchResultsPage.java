package org.example;

import org.openqa.selenium.support.ui.ExpectedConditions;

public class SearchResultsPage {

    public String getThirdSearchResultTitle() {

        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(thirdBook));
        return getThirdSearchResultTitle.getText();
    }
}
