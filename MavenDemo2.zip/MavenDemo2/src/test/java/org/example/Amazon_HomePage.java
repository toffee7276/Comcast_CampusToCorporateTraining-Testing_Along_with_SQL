package org.example;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Amazon_HomePage {
    private Properties testData;

    @FindBy(id = "twotabsearchtextbox")
    private WebElement searchBox;
    private WebElement thirdBook;

    public Amazon_HomePage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        testData = new Properties();
        try {
            testData.load(Files.newInputStream(Paths.get("testdata.properties")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void searchFor(String searchTerm) {
        searchBox.sendKeys(searchTerm);
        searchBox.submit();
    }

    public String getSearchTerm(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, 100);
        wait.until(ExpectedConditions.visibilityOf(thirdBook));
        return testData.getProperty("searchTerm");
    }
}
