package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class AmazonSearchTest {
    private WebDriver driver;
    private Amazon_HomePage Amazon_HomePage;
    private SearchResultsPage searchResultsPage;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "ChromeDriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get("https://www.amazon.in/");
        Amazon_HomePage = new Amazon_HomePage(driver);
    }

    @Test
    public void testSearchAndDisplayThirdBook() {
        Amazon_HomePage.searchFor(Amazon_HomePage.getSearchTerm(driver));
        searchResultsPage = new SearchResultsPage();
        String thirdBookTitle = searchResultsPage.getThirdSearchResultTitle();
        System.out.println("Title of the third book: " + thirdBookTitle);
        Assert.assertNotNull(thirdBookTitle, "Third book title is null");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
