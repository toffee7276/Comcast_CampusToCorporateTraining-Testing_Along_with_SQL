import org.openqa.selenium.chrome.ChromeDriver;

import static java.lang.Thread.sleep;

public class WebDriver_Amazon_SampleDraft {
    public static void main(String[] args) throws InterruptedException {
        ChromeDriver cd = new ChromeDriver();
        cd.manage().window().maximize();
        cd.get("https://www.amazon.in/");
        Thread.sleep(9000);
        cd.quit();

    }
}

